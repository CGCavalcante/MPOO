package br.ufrpe.mpoo.helloworld;

import java.util.Date;

public class Application {
	public static void main(String[] args) {
		HelloWorld h1 = new HelloWorld();
		h1.setNome("Gabriel");
		Date nascimentoH1 = HelloWorld.createDate("04/12/1980 12:00:00");
		h1.setNascimento(nascimentoH1);
		h1.imprimir();
		
		HelloWorld h2 = new HelloWorld();
		h2.setNome("Gabriel 2");
		Date nascimentoH2 = HelloWorld.createDate("04/04/1980 12:00:00");
		h2.setNascimento(nascimentoH2);
		h2.imprimir();

		
		HelloWorld h3 = new HelloWorld();
		h3.setNome("Gabriel 3");
		h3.setNascimento(new Date());
		h3.imprimir();
		
		
		Teste a = new Teste();
		Teste a1 = new Teste();
		Teste a2 = new Teste();
		Teste.imprimir();
		
	}
}
