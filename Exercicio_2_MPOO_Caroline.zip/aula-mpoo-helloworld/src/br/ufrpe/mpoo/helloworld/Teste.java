package br.ufrpe.mpoo.helloworld;

public class Teste {
	private static  int contar = 0;
	
	public Teste(){
		contar++;
	}
	
	public static void imprimir(){
		System.out.println(contar);
	}
}