import java.util.Date;
import java.text.SimpleDateFormat;


public class HelloWorld {
	private String nome;
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
	public String getNome(){
		return this.nome;
	}
	
	public void imprimir(){
		System.out.println(this.horaAgora() + " - Ol�, " + this.getNome() + "! Voc� acabou de fazer seu primeiro Hello World em .java Parab�ns!");
	}
	
	public String horaAgora(){
		Date data = new Date();
		SimpleDateFormat hora = new SimpleDateFormat("HH:mm:ss");
		
		return hora.format(data);
	}

}
