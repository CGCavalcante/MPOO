
public class Application {

	public static void main(String[] args) {
		HelloWorld objeto1 = new HelloWorld();
		objeto1.setNome("Gabriel");
		objeto1.imprimir();

		HelloWorld objeto2 = new HelloWorld();
		objeto2.setNome("Jo�o");
		objeto2.imprimir();
		
		HelloWorld objeto3 = new HelloWorld();
		objeto3.setNome("Caroline");
		objeto3.imprimir();
		
		HelloWorld objeto4 = new HelloWorld();
		objeto4.imprimir();
		
	}

}
