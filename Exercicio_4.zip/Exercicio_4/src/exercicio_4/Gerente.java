package exercicio_4;

public class Gerente extends Funcionario {
	
	private String area;

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	public void imprimir(String codigo){
		System.out.println("\n" + this.getNome() + "\nC�digo: " + codigo + "\nAtua na �rea: " + this.getArea());
		System.out.println("Salario: R$ " + this.getSalario());
		System.out.println("Custo: R$ "+ this.getCusto());
	}
}
