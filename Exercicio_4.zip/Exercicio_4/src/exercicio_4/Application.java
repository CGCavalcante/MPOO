package exercicio_4;

public class Application {
	public static void main(String[] args) {
		
		Gerente Joao = new Gerente();
		Joao.setNome("Jo�o Paulo Gomes Caetano");
		Joao.setArea("T.I.");
		Joao.setSalario(13000);
		Joao.lista.add(Joao.getNome());
		Joao.imprimir("4567");
		Joao.aumento();
		Joao.imprimir();
		
		Secretaria Janaina = new Secretaria();
		Janaina.setNome("Janaina Barbosa da Silva");
		Janaina.setSalario(1500);
		Janaina.setResponsavel("Jo�o Paulo Gomes Caetano");
		Janaina.lista.add(Janaina.getNome());
		Janaina.imprimir("3456");
		Janaina.aumento(25);
		Janaina.imprimir();
		
		AnalistaDeSistemas Amara = new AnalistaDeSistemas();
		Amara.setNome("Amara Ara�jo Cavalcante");
		Amara.setSalario(5000);
		Amara.setProjeto("R.U.");
		Amara.lista.add(Amara.getNome());
		Amara.imprimir("2345");
		Amara.aumento(15);
		Amara.imprimir();
		
		Programador Adriano = new Programador();
		Adriano.setNome("Adriano Pereira da Silva");
		Adriano.setFuncao("Desenvolverdor Java");
		Adriano.setSalario(3000);
		Adriano.lista.add(Adriano.getNome());
		Adriano.imprimir("1234");
		Adriano.aumento(31);
		Adriano.imprimir();
				
		Funcionario roberto = new Funcionario();
		roberto.setNome("Roberto Ferreira Campos");
		roberto.setSalario(3000);
		roberto.lista.add(roberto.getNome());
		roberto.imprimir();
		roberto.aumento();
		roberto.imprimir();
		
		
		roberto.imprimirLista();
		
	}

}