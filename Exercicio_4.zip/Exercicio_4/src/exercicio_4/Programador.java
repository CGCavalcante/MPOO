package exercicio_4;

public class Programador extends Funcionario{
	
	private String funcao;
	
	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	public void imprimir(String codigo){
		System.out.println("\n" + this.getNome() + "\nC�digo: " + codigo + "\nFun��o: " + this.getFuncao());
		System.out.println("Salario: R$ " + this.getSalario());
		System.out.println("Custo: R$ "+ this.getCusto());
	}

}
