package exercicio_4;

public class AnalistaDeSistemas extends Funcionario{
	private String projeto;

	public String getProjeto() {
		return projeto;
	}

	public void setProjeto(String projeto) {
		this.projeto = projeto;
	}
	
	public void imprimir(String codigo){
		System.out.println("\n" + this.getNome() +"\nC�digo: " + codigo+  "\nProjeto envolvido: " + this.getProjeto());
		System.out.println("Salario: R$ " + this.getSalario());
		System.out.println("Custo: R$ "+ this.getCusto());
	}

}
