package exercicio_4;

public class Secretaria extends Funcionario {
	private String responsavel;

	public String getResponsavel() {
		return responsavel;
	}

	public void setResponsavel(String gerente) {
		this.responsavel = gerente;
	}
	public void imprimir(String codigo){
		System.out.println("\n" + this.getNome()+ "\nC�digo: " + codigo + "\nSecret�ria de: " + this.getResponsavel());
		System.out.println("Salario: R$ " + this.getSalario());
		System.out.println("Custo: R$ "+ this.getCusto());
	}

}
