package exercicio_3;

public class Gerente extends Funcionario {
	
	private String area;

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	
	public void imprimir() { 
        System.out.println(this.getNome() + " � um(a) Gerente, ganha R$" + this.getSalario() + " e tem um custo de R$" + this.getCusto() + ". Sua �rea �: " + this.getArea());
    }

}
