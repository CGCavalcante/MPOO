package exercicio_3;

public class Secretaria extends Funcionario {
	private String responsavel;

	public String getResponsavel() {
		return responsavel;
	}

	public void setResponsavel(String gerente) {
		this.responsavel = gerente;
	}
	
	public void imprimir() { 
        System.out.println(this.getNome() + " � Secretaria(o), ganha R$ " + this.getSalario() + " e tem um custo de R$ " + this.getCusto() + ". Seu respons�vel �: " + this.getResponsavel());
	}
	

}
