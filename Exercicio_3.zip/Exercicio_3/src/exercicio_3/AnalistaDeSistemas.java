package exercicio_3;

public class AnalistaDeSistemas extends Funcionario{
	private String projeto;

	public String getProjeto() {
		return projeto;
	}

	public void setProjeto(String projeto) {
		this.projeto = projeto;
	}
	
	public void imprimir() { 
        System.out.println(this.getNome() + " � um(a) Analista de Sistemas, ganha R$ " + this.getSalario() + " e tem um custo de R$ " + this.getCusto() + ". Esta desenvolvendo o projeto " + this.getProjeto());
    }

}
