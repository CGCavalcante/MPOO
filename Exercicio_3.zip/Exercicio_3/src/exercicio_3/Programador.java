package exercicio_3;

public class Programador extends Funcionario{
	
	private String funcao;
	
	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

	public void imprimir() { 
        System.out.println(this.getNome() + " � um programador, ganha R$ " + this.getSalario() + " e tem um custo de R$ " + this.getCusto() + ". Sua fun��o �: " + this.getFuncao());
          }

}
