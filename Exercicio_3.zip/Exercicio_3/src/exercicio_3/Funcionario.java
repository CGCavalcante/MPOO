package exercicio_3;

import java.util.ArrayList;

public class Funcionario {
	public static ArrayList<String> lista = new ArrayList<String>();
	private static final double PERCENTUAL_CUSTO = 1.8;
	private String nome;
	private double salario;
	private double custo;

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setSalario(double salario) {
		this.salario = salario;
		this.custo = salario * PERCENTUAL_CUSTO;
	}

	public String getNome() {
		return this.nome;
	}

	public double getSalario() {
		return this.salario;
	}

	public double getCusto() {
		return this.custo;
	}
	
	public void imprimir(){
		System.out.println(this.getNome() + " ganha" + this.getSalario() + " e tem um custo de " + this.getCusto());
	}
	public ArrayList getLista() {
		return lista;
	}
	public void setLista(ArrayList lista) {
		this.lista = lista;
	}
	public void imprimirLista(){
		System.out.println("Listagem de Todos os Funcion�rios da empresa: " + this.getLista());
	}
	
	
}
