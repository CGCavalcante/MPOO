package exercicio_3;

public class Application {
	public static void main(String[] args) {
		
		Secretaria Janaina = new Secretaria();
		Janaina.setNome("Janaina Barbosa da Silva");
		Janaina.setSalario(1500);
		Janaina.setResponsavel("Jo�o Paulo Gomes Caetano");
		Janaina.lista.add("Janaina");
		Janaina.imprimir();
		
		Gerente Joao = new Gerente();
		Joao.setNome("Jo�o Paulo Gomes Caetano");
		Joao.setArea("T.I.");
		Joao.setSalario(13000);
		Joao.lista.add("Joao");
		Joao.imprimir();
		
		AnalistaDeSistemas Amara = new AnalistaDeSistemas();
		Amara.setNome("Amara Ara�jo Cavalcante");
		Amara.setSalario(5000);
		Amara.setProjeto("R.U.");
		Amara.lista.add("Amara");
		Amara.imprimir();
		
		Programador Adriano = new Programador();
		Adriano.setNome("Adriano Pereira da Silva");
		Adriano.setFuncao("Desenvolverdor Jr.");
		Adriano.setSalario(3000);
		Adriano.lista.add("Adriano");
		Adriano.imprimir();
		Adriano.imprimirLista();
		
	}

}